Le script de la machine X crée automatiquement `current/` avec :
- grype.rpm
- db-cache.tar.gz (copie du cache de X, pas une archive db import)
- manifest.json

Ne pas lancer la campagne avant la première publication réussie.

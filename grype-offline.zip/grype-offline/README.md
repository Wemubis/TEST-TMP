# Grype - publication depuis X, exécution par Satellite

| Où | Contenu / action |
|---|---|
| Machine X, avec Internet | Script Bash : contrôle, téléchargement, validation et push GitLab. |
| GitLab | Les deux rôles et la distribution courante : RPM, archive DB et manifeste. |
| Satellite | Playbook, liste des hôtes DEV et planification de la campagne. |
| Capsule DEV | Installation et restauration locales depuis GitLab, puis scans et rapports. |

## 1. Déposer les rôles dans GitLab

Mettre **le contenu de `gitlab/` à la racine du dépôt**. Il contient `roles/`.
La branche choisie, par exemple `main`, doit déjà exister.
Les anciens playbooks racine, inventaires Git et anciens Job Templates sont
remplacés par le nouveau playbook Satellite de ce paquet.

Le script publiera automatiquement :

```text
roles/maj_grype_capsule/files/current/
  grype.rpm
  db-cache.tar.gz
  manifest.json
```

Aucun vrai RPM ni aucune DB ne sont inclus dans ce paquet : exécuter la première
synchronisation avant de lancer le rôle sur DEV.

## 2. Sur la machine X

X doit être une machine Linux de **même architecture que la capsule DEV**
(x86_64 ou aarch64). Le script fonctionne sans root et n'installe pas Grype sur X.
Il utilise le **Grype déjà installé sur X**. Celui-ci doit être à la dernière
version stable : sinon le script s'arrête avec la version attendue, sans publier.
La mise à jour du logiciel sur X reste à gérer par votre gestion de paquets ;
`grype db update` met uniquement à jour la base.

Prérequis : Grype installé, Bash, curl, jq, git, GNU tar, gzip, sha256sum, flock, outils coreutils ; accès
HTTPS GitHub/Anchore et accès SSH en écriture au dépôt GitLab. La clé SSH et le
known_hosts doivent fonctionner sans interaction. La branche doit autoriser le
push du compte de synchronisation.

Copier `machine-x/synchroniser-grype.sh` sur X puis lancer :

```bash
GITLAB_DEPOT='git@gitlab.exemple.fr:infra/grype.git' \
GITLAB_BRANCHE='main' \
bash synchroniser-grype.sh
```

Variables facultatives : `SYNC_CACHE` (cache de travail), `GIT_AUTHOR_NAME` et
`GIT_AUTHOR_EMAIL` (identité du compte technique dans les commits).
Le proxy HTTPS éventuel se configure via l'environnement habituel de curl.
Prévoir de l'espace pour le clone, les téléchargements et la DB décompressée.

À chaque passage, le script :

1. Vérifie la dernière version officielle et celle de Grype installé sur X.
2. Lance `grype db update`, puis `grype db status` dans un cache persistant dédié.
3. Compare le contenu DB et le RPM aux fichiers publiés dans GitLab.
4. Archive le cache si la DB a changé et télécharge le RPM seulement si nécessaire.
5. Teste le cache restauré, remplace `files/current/` et pousse **un seul commit**.

Le cache de X se trouve dans `$SYNC_CACHE/db` (par défaut
`~/.cache/grype-sync/db`). Il est réservé au script. La première exécution y
initialise la DB ; les suivantes utilisent la vérification de mise à jour Grype.
L'archive conserve les répertoires de schéma et les métadonnées ; Ansible la
restaure directement dans `GRYPE_DB_CACHE_DIR`, sans `grype db import`.

Si tout est à jour : aucun commit. Une DB seule peut être actualisée sans changer
le RPM. Si une vérification échoue : rien n'est publié. Si GitLab refuse le push,
le script échoue sans force-push ; corriger la cause ou relancer après un push
concurrent. Le dernier contenu publié reste disponible.

**Remplacement Git :** seuls les trois fichiers courants restent visibles dans
la branche. Les anciennes versions restent dans l'historique Git ; ce script
ne le réécrit pas. La DB quotidienne fera grossir le dépôt. Vérifier la limite
de taille des fichiers/pushs de votre GitLab avant le premier essai. Le clone
GitLab récupère les fichiers courants même s'ils n'ont pas changé sur Internet.
Si vous voulez réellement purger les anciens binaires du stockage, il faudra
utiliser le Package Registry GitLab avec une politique de rétention.

## 3. Dans Satellite

Importer **`satellite/playbook-grype-dev.yml`**, fournisseur **Ansible**, en
remplacement du précédent Job Template. Utilisateurs SSH et effectif :
**satellite**. Cibler uniquement la capsule DEV.

Modifier les variables en tête du playbook :

```yaml
gitlab_depot: git@TON_GITLAB:TON_GROUPE/TON_DEPOT.git
gitlab_ref: main
grype_action: campagne  # ou maj pour tester uniquement RPM + DB
scan_hotes:
  hote-dev-01:
    ansible_host: IP_REELLE
```

Le playbook reste défini dans Satellite. Pour exécuter les rôles sur la capsule,
il y matérialise un petit playbook temporaire, puis le supprime en fin de job.
Il n'exécute plus de playbook principal versionné dans GitLab.
Les playbooks internes du rôle de scan restent des fichiers de ce rôle.

Le job récupère une révision GitLab cohérente contenant les rôles, le RPM et la
DB, affiche le commit utilisé, puis lance MAJ et scan sous un verrou commun.
Les anciennes copies déjà récupérées par un job restent utilisables même si X
publie une nouvelle révision pendant ce job.

## 4. Comportement de la capsule

Le rôle de MAJ :
- vérifie l'architecture et les SHA-256 ;
- installe le RPM local si la version diffère ou si Grype est absent ;
- restaure le cache DB local si son empreinte a changé ou si le cache est invalide ;
- vérifie la DB avant d'autoriser les scans.

Les mises à jour automatiques Internet de Grype sont désactivées. DNF utilise
uniquement le fichier local, avec les dépôts réseau désactivés. Les éventuelles
dépendances système doivent donc être déjà installées. La vérification GPG du
RPM reste désactivée comme dans la version précédente ; SHA-256 obligatoire.

Prérequis capsule : RHEL, Python 3.9+, ansible-core 2.14+, Git, flock et sudo non
interactif pour satellite. Accès lecture GitLab et SSH aux hôtes. Les clés privées
et les tokens ne doivent jamais être déposés dans le dépôt. La politique de
fraîcheur de la DB reste active : une base trop ancienne fait échouer le job.

Le rôle de scan reste identique : inventaire parallèle avant les extractions,
déduplication des images, transferts, scan sur la capsule, puis CSV/HTML/JSON.
Résultats : `/var/lib/vulnscan/campagne-*/` ; journal :
`/var/lib/vulnscan/derniere-campagne.log`.

## Ordre de mise en service

1. Pousser les rôles dans GitLab.
2. Lancer le script sur X et vérifier son push.
3. Tester le job Satellite avec `grype_action: maj` sur DEV.
4. Passer à `campagne`, puis planifier quotidiennement après la synchronisation X.

Planifier X avec votre ordonnanceur habituel ; Satellite planifie les campagnes.
Supprimer/désactiver les anciennes planifications avant de basculer. Aucun job
réel, accès à votre infrastructure ou planning n'a été créé depuis cette session.

## Vérifications du paquet

Contrôle de syntaxe Bash/Ansible. Tests avec un dépôt Git local et des artefacts
simulés : première publication, absence de changement, DB seule, échec de mise à jour, version X différente,
cache invalide et push refusé. Le rôle RPM/DB reste à tester sur votre capsule.

Références Grype :
https://oss.anchore.com/docs/reference/grype/cli/
https://oss.anchore.com/docs/reference/grype/configuration/

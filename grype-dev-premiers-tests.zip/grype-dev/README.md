# Grype — capsule DEV

**Deux rôles. Un seul script Python, réservé aux CSV et au HTML.**

- `maj_grype_capsule` : installe/actualise Grype et sa DB.
- `scan_images_capsule` : inventorie les hôtes en parallèle, déduplique les images,
  exporte/transfère/scanne chaque image une fois, nettoie et produit les rapports.

Toutes les images Docker/Podman rootful sont listées, même sans tag. La liste
complète est sauvegardée **avant la première extraction**. Les hôtes en échec
restent visibles dans le bilan ; les autres continuent. Si une source échoue,
Ansible essaie une autre source de la même image.

## Configuration

Dans `inventaires/dev.yml`, renseigner :

1. L'adresse de la capsule DEV.
2. Les adresses des hôtes dans `scan_hotes` (les IP fournies restent à confirmer).

L'utilisateur est **satellite**. Le scan s'exécute sous ce compte sur la capsule,
avec sa clé SSH habituelle : aucune clé n'est copiée ni générée. Les rapports et
le cache DB lui appartiennent. Vérifier que les hôtes figurent aussi dans son
`known_hosts`. Une clé dans un emplacement personnalisé peut être indiquée par
`ansible_ssh_private_key_file` dans les variables des cibles.

Prérequis : capsule RHEL x86_64/aarch64, Python 3.9+, ansible-core 2.14+, flock,
accès HTTPS à GitHub et à la DB Anchore. Les hôtes ont Python et Docker/Podman.
**satellite doit pouvoir utiliser sudo sans interaction** pour installer Grype
sur la capsule et exporter les images rootful sur les hôtes. Le rôle reprend
le téléchargement RPM vérifié SHA-256 et le contrôle GPG désactivé du premier
paquet. Adapter cette politique si le RPM est resigné en interne.

Pour Podman rootless, définir `ansible_become: false` sur la cible et utiliser
le compte qui possède ses images. La liste des cibles reste explicite : aucun
balayage réseau n'est effectué.

## Test

Depuis le dossier extrait :

```bash
ansible-playbook -i inventaires/dev.yml playbook-campagne-scan.yml
```

Ce playbook fait déjà la MAJ avant le scan. Pour tester seulement la MAJ :

```bash
ansible-playbook -i inventaires/dev.yml playbook-maj-grype.yml
```

Si vous lancez depuis la capsule, décommenter `ansible_connection: local` dans
son inventaire. Les campagnes ne se lancent pas avec `--check`.

## Automatisation quotidienne

Après validation du test :

```bash
ansible-playbook -i inventaires/dev.yml playbook-automatiser-dev.yml
```

Ansible déploie le projet dans `/opt/grype-dev` puis active un service/timer
systemd, sous **satellite**, à **02:00 Europe/Paris**. `Persistent=true` permet
le rattrapage d'une échéance manquée. L'activation reste une étape explicite.
Pour changer l'heure, passer `-e 'calendrier=*-*-* 03:00:00 Europe/Paris'`.
Relancer ce playbook après une modification pour actualiser le projet déployé.

Contrôle sur la capsule :

```bash
systemctl list-timers grype-dev.timer
journalctl -u grype-dev.service
```

## Résultats

Sous `/var/lib/vulnscan/campagne-*/` :

- `inventaire.json` : hôtes, tags et images uniques avant transfert.
- `bilan.json` : état des hôtes/scans, source utilisée, version Grype et DB.
- `json/`, `csv/`, `rapport.html` : résultats et rendu basé sur vos templates.

Le dernier journal complet est `/var/lib/vulnscan/derniere-campagne.log`.
Une campagne sans vulnérabilité produit également un rapport. Le CSV est écrit
avec le module Python `csv` selon l'en-tête fourni, puis enrichi avec Machine et
Image. Les données sont répétées par hôte/tag ; le bilan compte les scans uniques.
Les fonctions DataTables/exports du HTML nécessitent les CDN du template.

Une seule archive est traitée à la fois. Son transfert SSH ne passe pas par
`sudo`, pour éviter le chargement en mémoire par `fetch`. Les exports restent
faits avec les privilèges de la cible. Les dossiers temporaires sont nettoyés ;
les campagnes sont conservées pour les tests, sans purge automatique.

## GitLab / Satellite

Versionner ce dossier dans GitLab. Le `.gitlab-ci.yml` fourni vise un runner
shell dédié sur la capsule DEV, tagué `capsule-dev`, avec les droits sudo requis.
Il autorise les lancements manuels et Pipeline Schedules.

Dans Satellite : installer/importer les deux rôles depuis le dépôt GitLab,
puis cibler **la capsule DEV elle-même**, via satellite avec élévation root.
Transmettre `scan_hotes`, exécuter MAJ puis scan dans cet ordre. Une affectation
de rôles seule ne garantit pas l'ordre ; vérifier le job généré.

Choisir **un seul planificateur** : timer systemd, GitLab ou Satellite.
Les scans sont protégés par verrou et GitLab par `resource_group`. Le service
quotidien verrouille aussi l'ensemble MAJ/scan. Ne pas lancer une MAJ manuelle
ou un job externe pendant une autre campagne.

## Vérification

Syntaxe Ansible/Python vérifiée. Intégration avec Ansible réel et moteurs/Grype
simulés : déduplication, source de secours, hôte injoignable, scan en échec,
rapport vide et nettoyage. Aucun test sur votre infrastructure n'a été effectué.

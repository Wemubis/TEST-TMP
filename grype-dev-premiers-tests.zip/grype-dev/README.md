# Grype — GitLab / Satellite / capsule DEV

| Élément | Responsabilité |
|---|---|
| GitLab | Versionner les rôles, playbooks, inventaire et templates. |
| Satellite | Déclencher, planifier et suivre les jobs. |
| Capsule DEV | Récupérer le code GitLab, mettre à jour Grype/DB et exécuter la campagne. |
| Hôtes DEV | Fournir la liste des images et leurs exports par SSH. |

Le compte utilisé est **satellite**, avec sa clé SSH existante. Les opérations
rootful utilisent sudo. Python sert uniquement aux CSV et au rapport HTML.

## Mise en place

1. Pousser **le contenu du dossier `grype-dev` à la racine d'un dépôt GitLab**.
2. Dans `inventaires/dev.yml`, renseigner les hôtes DEV dans `scan_hotes`.
   La capsule reste en `ansible_connection: local` : Satellite lance le code
   directement sur la capsule sélectionnée.
3. Dans `satellite/job-campagne-dev.yml`, renseigner `gitlab_depot` et
   `gitlab_ref` (branche ou tag).
4. Dans Satellite : **Hosts → Templates → Job templates → New Job Template**.
   Importer le contenu de ce fichier, choisir le fournisseur **Ansible**, une
   catégorie `Grype`, et l'utilisateur effectif **satellite**. Configurer aussi
   l'utilisateur SSH `satellite` pour la capsule et les bonnes organisation/location.
5. Lancer ce job en ciblant **uniquement l'hôte capsule DEV**.
6. Après validation, rendre ce même job récurrent dans Satellite : une fois par
   jour, par exemple à 02:00, en vérifiant le fuseau Europe/Paris.

Les libellés peuvent varier selon la version de Satellite. Utiliser la récurrence
du job personnalisé, afin de rejouer le même template et la même sélection DEV.
Ne pas choisir une sélection dynamique qui pourrait inclure d'autres capsules.

## Ce que fait le job

1. Clone la branche ou le tag GitLab dans un dossier privé temporaire.
2. Affiche le SHA du commit utilisé dans les résultats Satellite.
3. Sous un verrou commun, lance `maj_grype_capsule` puis `scan_images_capsule`.
4. Retourne à Satellite un succès ou un échec, puis supprime la copie temporaire
   du dépôt. Les résultats de scan restent sur la capsule.

Les rôles sont chargés depuis le dépôt récupéré par le job. Une modification
validée et poussée sur la branche choisie sera utilisée au prochain lancement.
Le Job Template lui-même reste dans Satellite : réimporter son contenu si vous
modifiez `satellite/job-campagne-dev.yml`.

Pour une MAJ seule, dupliquer le template dans Satellite et définir
`grype_action: maj`. Il utilise le même verrou que la campagne complète.

## Prérequis

- Satellite/Remote Execution avec fournisseur Ansible opérationnel pour DEV.
- Capsule RHEL x86_64/aarch64 : git, Python 3.9+, ansible-core 2.14+, flock, dnf.
- Compte `satellite` sur la capsule, avec sa clé privée et les hôtes connus SSH.
- Lecture du dépôt GitLab autorisée à cette clé (par exemple une Deploy Key
  **lecture seule**) et clé du serveur GitLab validée dans `known_hosts`.
  L'accès aux hôtes conteneurs ne donne pas automatiquement accès à GitLab.
- Sudo non interactif pour satellite sur la capsule et les hôtes rootful.
- HTTPS de la capsule vers GitHub et les endpoints de DB Anchore.
- Timeout du job Satellite suffisant pour l'ensemble des exports et scans.

Le RPM Grype est vérifié par SHA-256 ; le contrôle GPG est désactivé comme dans
la version fournie initialement. Adapter si vous distribuez un RPM resigné.
Pour Podman rootless, configurer le compte propriétaire et `ansible_become: false`
sur la cible. Aucun secret ni clé privée ne doit être ajouté au dépôt.

## Campagne et résultats

L'inventaire Docker/Podman se fait en parallèle sur les hôtes configurés, y compris
les images sans tag. La liste complète est écrite avant toute extraction.
Une seule archive par image SHA-256 est transférée et scannée ; une autre source
est essayée si la première échoue. Les archives temporaires sont nettoyées.

Dans `/var/lib/vulnscan/campagne-*/` :

- `inventaire.json` : hôtes, images et tags avant transfert.
- `bilan.json` : état des scans/hôtes, version Grype et état de la DB.
- `json/`, `csv/`, `rapport.html` : résultats basés sur vos templates.

Journal complet : `/var/lib/vulnscan/derniere-campagne.log`.
Les fichiers appartiennent à satellite. Un scan sans vulnérabilité produit un
rapport ; les échecs restent visibles et font échouer le job Satellite.
Les compteurs CSV/HTML sont par hôte/tag, le bilan compte les scans uniques.
Les fonctions interactives du HTML nécessitent les CDN du template.
Les anciennes campagnes sont conservées pour les tests.

## Ancienne version

Le timer systemd et le pipeline GitLab CI ont été retirés du paquet. La campagne
désactive automatiquement l'ancien timer `grype-dev.timer` s'il existe sur DEV.
Si une ancienne campagne tourne déjà, attendre sa fin avant le premier job.
Désactiver aussi tout ancien Pipeline Schedule créé dans GitLab.

## Vérifications

Syntaxe Ansible contrôlée. Le nouveau job a été testé avec un dépôt Git local
et une campagne simulée : clonage, verrou commun, retour de succès/échec et
nettoyage du checkout. Le moteur de campagne conserve les tests locaux
précédents : déduplication, source de secours, hôte injoignable, scan en échec,
rapport vide et nettoyage. Aucun job n'a été créé ni exécuté sur votre Satellite.

Référence : https://docs.redhat.com/en/documentation/red_hat_satellite/6.18/html/managing_hosts/configuring-and-setting-up-remote-jobs

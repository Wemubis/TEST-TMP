#!/usr/bin/env python3
"""Fusionne les CSV en un rapport HTML unique, à partir de html.tmpl.

html.tmpl est un template Grype mono-analyse. On le réutilise comme enveloppe
(mise en forme, DataTables, exports) et on remplit le tableau nous-mêmes, avec
deux colonnes en plus : Machine et Image, ajoutées EN FIN de tableau car le
template référence ses colonnes par index de 0 à 9.

Usage : python3 generer-rapport.py --dossier DOSSIER_DE_CAMPAGNE
"""
import csv, html, re, sys, json, argparse
from datetime import datetime
from pathlib import Path

TEMPLATE = Path(__file__).with_name("html.tmpl")
SORTIE = Path("rapport.html")
SEVERITES = ["Critical", "High", "Medium", "Low", "Negligible", "Unknown"]

# Le template charge ses icônes depuis api.iconify.design et cdn.jsdelivr.net.
# Si ces domaines sont injoignables, les boutons d'export apparaissent comme des
# cases grises et un espace vide précède chaque type de paquet.
# Mettre à True si votre poste atteint ces domaines.
ICONES_EXTERNES = False

# Colonnes produites par csv.tmpl, plus les deux ajoutées par le script.
REQUISES = ["Machine", "Image", "Package", "Version Installed", "Type",
            "Vulnerability ID", "Severity", "Fix State", "Fixed In", "Data Source"]


def lire(chemins):
    lignes = []
    for c in chemins:
        with open(c, encoding="utf-8", newline="") as f:
            lecteur = csv.DictReader(f)          # format CSV standard
            entete = lecteur.fieldnames or []

            manquantes = [col for col in REQUISES if col not in entete]
            if manquantes:
                sys.exit(f"{c} : colonnes absentes {manquantes}\n"
                         f"  en-tete lu : {entete}")

            lues = list(lecteur)

            # Valeurs vides ou littérales : signe que l'étape awk du script
            # de scan n'a pas fonctionné (typiquement NR=1 au lieu de NR==1).
            suspectes = {(l.get("Machine") or "").strip() for l in lues}
            if lues and suspectes <= {"", "Machine"}:
                sys.exit(f"{c} : la colonne Machine ne contient pas de nom de "
                         f"machine mais {suspectes}.\n"
                         f"  -> verifier le bloc awk du script de scan "
                         f"(NR==1 et non NR=1)")
            lignes += lues

    lignes.sort(key=lambda l: SEVERITES.index(l["Severity"])
                if l["Severity"] in SEVERITES else 99)
    return lignes


def e(v):
    return html.escape((v or "").strip())


def corps(lignes):
    out = []
    for l in lignes:
        src = e(l["Data Source"])
        vuln = e(l["Vulnerability ID"])
        lien = f'<a href="{src}">{vuln}</a>' if l["Data Source"].startswith(("https://", "http://")) else vuln
        out.append(
            "<tr>"
            f"<td>{e(l['Package'])}</td><td>{e(l['Version Installed'])}</td>"
            f"<td>{e(l['Type'])}</td>"
            f"<td>{lien}</td>"
            f"<td>{e(l['Severity'])}</td><td>{e(l['Fix State'])}</td>"
            f"<td>{e(l['Fixed In']) or 'N/A'}</td>"
            f"<td></td>"                      # Description : absente du CSV
            f"<td>{src}</td>"                 # Related URLs
            f"<td></td>"                      # PURL : absente du CSV
            f"<td>{e(l['Machine'])}</td><td>{e(l['Image'])}</td>"
            "</tr>")
    return "\n".join(out)


def produire_csv(dossier, image, donnees):
    with (Path(__file__).with_name('csv.tmpl')).open() as f:
        header = next(csv.reader(f))
    # Même schéma que le template fourni, avec échappement CSV standard.
    with (dossier / 'csv' / (image['id'] + '.csv')).open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(header + ['Machine', 'Image'])
        presences = {(p['hote'], ref) for p in image['porteurs'] for ref in p['refs']}
        for match in donnees.get('matches', []):
            a, v = match['artifact'], match['vulnerability']
            fix = v.get('fix') or {}
            ligne = [a.get('name', ''), a.get('version', ''), a.get('type', ''),
                     v.get('id', ''), v.get('severity', 'Unknown'), fix.get('state', ''),
                     ' '.join(fix.get('versions') or []), v.get('dataSource', '')]
            for hote, ref in sorted(presences):
                writer.writerow(ligne + [hote, ref + ' [sha256:' + image['id'] + ']'])


def main():
    global SORTIE
    parser = argparse.ArgumentParser()
    parser.add_argument('--dossier', type=Path, required=True)
    args = parser.parse_args()
    SORTIE = args.dossier / 'rapport.html'
    bilan = json.loads((args.dossier / 'bilan.json').read_text())
    for image in bilan['images']:
        if image['statut'] == 'ok':
            data = json.loads((args.dossier / 'json' / (image['id'] + '.json')).read_text())
            if not isinstance(data.get('matches'), list):
                raise ValueError('Résultat JSON Grype invalide')
            image['vulnerabilites'] = len(data['matches'])
            produire_csv(args.dossier, image, data)
    (args.dossier / 'bilan.json').write_text(json.dumps(bilan, ensure_ascii=False, indent=2))
    fichiers = sorted(args.dossier.glob('csv/*.csv'))

    lignes = lire(fichiers)
    page = TEMPLATE.read_text(encoding="utf-8")

    # 1. Retirer le bloc Go de comptage et de filtrage, en tête de fichier.
    page = re.sub(r"\{\{/\* Initialize counters \*/\}\}.*?\n<body>", "<body>",
                  page, count=1, flags=re.S)

    # 2. Remplacer l'en-tête, prévu pour une seule image.
    machines = sorted(bilan['hotes'])
    images = sorted({i['id'] for i in bilan['images']})
    entete = (f'<dl class="report-details">'
              f'<dt>Machines:</dt><dd id="nameValue">{e(", ".join(machines))}</dd>'
              f'<dt>Images:</dt><dd>{len(images)} : {e(", ".join(images))}</dd>'
              f'<dt>Date:</dt><dd><span id="dateElement">'
              f'{datetime.now().astimezone().isoformat(timespec="seconds")}</span>'
              f'<span id="prettyDateElement" style="display:none"></span></dd></dl>')
    page = re.sub(r'<dl class="report-details">.*?</dl>', lambda _: entete,
                  page, count=1, flags=re.S)

    # 3. Compteurs par sévérité.
    for s in SEVERITES:
        n = sum(1 for l in lignes if l["Severity"] == s)
        page = page.replace("{{ $Count%s }}" % s, str(n))

    # Sévérité également produite par Grype, absente du template initial.
    page = page.replace('<div class="severity-box" id="unknown">',
        '<div class="severity-box" id="negligible" style="background:#5cb85c">'
        '<div class="severity-title">Negligible</div>'
        '<div class="severity-count" id="negligibleCount">%s</div></div>' %
        sum(l['Severity'] == 'Negligible' for l in lignes) +
        '<div class="severity-box" id="unknown">', 1)

    # 4. Deux colonnes en plus dans l'en-tête du tableau.
    page = page.replace("<th>PURL</th>",
                        "<th>PURL</th><th>Machine</th><th>Image</th>", 1)

    # 5. Corps du tableau. L'ancrage sur </tbody> est indispensable : la boucle
    #    contient une boucle interne dont le {{- end }} serait pris pour la fin.
    page = re.sub(r"\{\{- range \$FilteredMatches \}\}.*?\{\{- end \}\}\s*</tbody>",
                  lambda _: corps(lignes) + "</tbody>", page, count=1, flags=re.S)

    # 6. Déclarer les deux colonnes à DataTables.
    page = page.replace(
        "                className: 'none', // Tell Responsive to hide this column initially\n"
        "            },\n        ];",
        "                className: 'none', // Tell Responsive to hide this column initially\n"
        "            },\n"
        "            { name: 'Machine', targets: 10, responsivePriority: 3 },\n"
        "            { name: 'Image',   targets: 11, responsivePriority: 4 },\n"
        "        ];", 1)

    # Conserver Machine et Image dans les exports du rapport agrégé.
    page = page.replace("'Fixed In:name'\n", "'Fixed In:name', 'Machine:name', 'Image:name'\n", 1)
    page = page.replace("'PURL:name'\n", "'PURL:name', 'Machine:name', 'Image:name'\n", 1)
    page = page.replace("doc.defaultStyle.alignment = 'left';", "doc.defaultStyle.alignment = 'left'; doc.pageOrientation = 'landscape';", 1)
    page = page.replace("['*', 'auto', 'auto', '*', 'auto', 'auto', '*'];", "['*', 'auto', 'auto', '*', 'auto', 'auto', '*', '*', '*'];", 1)

    # 7. Remplacer les icônes injoignables par du texte.
    if not ICONES_EXTERNES:
        page = page.replace(
            """text: '<span class="vscode-icons--file-type-pdf2"></span>',""",
            """text: 'PDF',""", 1)
        page = page.replace(
            """text: '<span class="vscode-icons--file-type-excel"></span>',""",
            """text: 'Excel',""", 1)
        # L'élément d'icône du type occupe de la place même vide : on le retire.
        page = page.replace(
            'return `<span class="pkg-type-cell">${iconHtml}<span>${data}</span></span>`;',
            'return `<span class="pkg-type-cell"><span>${data}</span></span>`;', 1)

    resume = '<section><h2>Bilan de campagne</h2><p>' + e(bilan['statut']) + '</p>'
    resume += '<p>%s images uniques ; %s scans réussis. Voir inventaire.json et bilan.json pour les références et les hôtes porteurs.</p>' % (len(images), sum(i['statut'] == 'ok' for i in bilan['images']))
    for h, etat in bilan['hotes'].items():
        resume += '<p>' + e(h) + ' : ' + e(etat['statut']) + ' ' + e(etat.get('erreur', '')) + '</p>'
    for image in bilan['images']:
        if image['statut'] != 'ok':
            resume += '<p>Échec ' + e(image['id']) + ' : ' + e(image.get('erreur', '')) + '</p>'
    page = page.replace('<div class="severity-info">', resume + '</section><div class="severity-info">', 1)
    if "{{" in page:
        raise ValueError("Directives Go restantes dans la page")

    SORTIE.write_text(page, encoding="utf-8")
    print(f"{len(lignes)} vulnérabilité(s), {len(images)} image(s), "
          f"{len(machines)} machine(s) -> {SORTIE}")


if __name__ == "__main__":
    main()
